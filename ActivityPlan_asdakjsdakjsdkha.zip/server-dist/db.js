import Database from 'better-sqlite3';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
export const db = new Database(join(__dirname, '../activity_plans.db'));
db.exec(`
  CREATE TABLE IF NOT EXISTS plans (
    id          TEXT PRIMARY KEY,
    title       TEXT NOT NULL DEFAULT '',
    type        TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'draft',
    version     TEXT NOT NULL DEFAULT '1.00',
    data        TEXT NOT NULL,
    self_check  TEXT,
    created_at  TEXT NOT NULL,
    updated_at  TEXT NOT NULL,
    published_at TEXT
  )
`);
db.exec(`
  CREATE TABLE IF NOT EXISTS plan_updates (
    id            TEXT PRIMARY KEY,
    plan_id       TEXT NOT NULL,
    author        TEXT NOT NULL DEFAULT '',
    message       TEXT NOT NULL DEFAULT '',
    activity_id   TEXT NOT NULL DEFAULT '',
    activity_name TEXT NOT NULL DEFAULT '',
    created_at    TEXT NOT NULL,
    FOREIGN KEY (plan_id) REFERENCES plans(id) ON DELETE CASCADE
  )
`);
// Inline migration: add activity columns if they don't exist on existing tables
const _updateCols = db.prepare('PRAGMA table_info(plan_updates)').all().map((c) => c.name);
if (!_updateCols.includes('activity_id')) {
    db.exec("ALTER TABLE plan_updates ADD COLUMN activity_id TEXT NOT NULL DEFAULT ''");
}
if (!_updateCols.includes('activity_name')) {
    db.exec("ALTER TABLE plan_updates ADD COLUMN activity_name TEXT NOT NULL DEFAULT ''");
}
db.exec(`
  CREATE TABLE IF NOT EXISTS company_holidays (
    id         TEXT PRIMARY KEY,
    date       TEXT NOT NULL,
    name       TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
  )
`);
db.exec(`
  CREATE TABLE IF NOT EXISTS activity_requests (
    id          TEXT PRIMARY KEY,
    title       TEXT NOT NULL DEFAULT '',
    description TEXT NOT NULL DEFAULT '',
    target_date TEXT NOT NULL DEFAULT '',
    it_number   TEXT NOT NULL DEFAULT '',
    pic         TEXT NOT NULL DEFAULT '',
    status      TEXT NOT NULL DEFAULT 'open',
    created_by  TEXT NOT NULL DEFAULT '',
    created_at  TEXT NOT NULL,
    updated_at  TEXT NOT NULL
  )
`);
db.exec(`
  CREATE TABLE IF NOT EXISTS approvers (
    id         TEXT PRIMARY KEY,
    name       TEXT NOT NULL,
    email      TEXT NOT NULL DEFAULT '',
    position   TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
  )
`);
db.exec(`
  CREATE TABLE IF NOT EXISTS plan_versions (
    id         TEXT PRIMARY KEY,
    plan_id    TEXT NOT NULL,
    version    TEXT NOT NULL,
    event      TEXT NOT NULL DEFAULT '',
    data       TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (plan_id) REFERENCES plans(id) ON DELETE CASCADE
  )
`);
db.exec(`CREATE INDEX IF NOT EXISTS idx_plan_versions_plan ON plan_versions (plan_id, version)`);
db.exec(`
  CREATE TABLE IF NOT EXISTS notifications (
    id            TEXT PRIMARY KEY,
    plan_id       TEXT NOT NULL,
    plan_title    TEXT NOT NULL DEFAULT '',
    it_number     TEXT NOT NULL DEFAULT '',
    plan_type     TEXT NOT NULL DEFAULT '',
    view_link     TEXT NOT NULL DEFAULT '',
    approvers     TEXT NOT NULL DEFAULT '[]',
    published_at  TEXT NOT NULL,
    dispatched    INTEGER NOT NULL DEFAULT 0,
    dispatched_at TEXT
  )
`);
