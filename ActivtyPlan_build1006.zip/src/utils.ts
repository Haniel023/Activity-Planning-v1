import type { ActivityRow, ActivityPlan, MonthConfig, PlanType, DevPersons, SupportPersons, DayMark, PICEntry, PersonEntry, Stakeholder, ApprovalSection } from './types'

export function generateId() {
  return Math.random().toString(36).slice(2, 9)
}

export function generateUUID(): string {
  // crypto.randomUUID() requires a secure context (HTTPS).
  // Fall back to a Math.random-based UUID v4 for plain HTTP deployments.
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID()
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = (Math.random() * 16) | 0
    return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16)
  })
}

export function monthLabel(m: MonthConfig) {
  return new Date(m.year, m.month, 1).toLocaleString('en-US', { month: 'short', year: 'numeric' })
}

export function daysInMonth(year: number, month: number): number {
  return new Date(year, month + 1, 0).getDate()
}

export function toDateStr(year: number, month: number, day: number): string {
  return `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`
}

// Use explicit local-date construction to avoid any DST / UTC edge cases
export function isWeekend(dateStr: string): boolean {
  const parts = dateStr.split('-')
  const y = parseInt(parts[0], 10)
  const m = parseInt(parts[1], 10) - 1
  const d = parseInt(parts[2], 10)
  const dow = new Date(y, m, d).getDay()
  return dow === 0 || dow === 6
}

export function dayOfWeekAbbr(dateStr: string): string {
  const parts = dateStr.split('-')
  const y = parseInt(parts[0], 10)
  const m = parseInt(parts[1], 10) - 1
  const d = parseInt(parts[2], 10)
  const dow = new Date(y, m, d).getDay()
  return ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'][dow]
}

export function dayNumber(dateStr: string): number {
  return parseInt(dateStr.split('-')[2], 10)
}

export function generateDayMarks(months: MonthConfig[]): DayMark[] {
  const marks: DayMark[] = []
  for (const m of months) {
    const days = daysInMonth(m.year, m.month)
    for (let d = 1; d <= days; d++) {
      marks.push({ date: toDateStr(m.year, m.month, d), plan: false, actual: false })
    }
  }
  return marks
}

export function syncDayMarks(existing: DayMark[], newMonths: MonthConfig[]): DayMark[] {
  const existingMap = new Map(existing.map(m => [m.date, m]))
  return generateDayMarks(newMonths).map(m => existingMap.get(m.date) ?? m)
}

export function makePICEntry(pic = ''): PICEntry {
  return { id: generateId(), pic, raci: { r: false, a: false, c: false, i: false } }
}

// ── Auto-numbering helpers ───────────────────────────────────────────────────

export function getNextPhaseNumber(activities: ActivityRow[]): string {
  const nums = activities
    .filter(a => a.isPhase)
    .map(a => parseInt(a.number.split('.')[0], 10))
    .filter(n => !isNaN(n) && n > 0)
  const max = nums.length > 0 ? Math.max(...nums) : 0
  return `${max + 1}.0`
}

export function getNextSubNumber(activities: ActivityRow[], afterIdx: number): string {
  let phaseNum = 1
  for (let i = afterIdx; i >= 0; i--) {
    if (activities[i]?.isPhase) {
      const n = parseInt(activities[i].number.split('.')[0], 10)
      if (!isNaN(n) && n > 0) { phaseNum = n; break }
    }
  }
  const prefix = `${phaseNum}.`
  const subs = activities
    .filter(a => !a.isPhase && a.number.startsWith(prefix))
    .map(a => {
      const parts = a.number.split('.')
      return parts.length > 1 ? parseInt(parts[1], 10) : 0
    })
    .filter(n => !isNaN(n))
  const maxSub = subs.length > 0 ? Math.max(...subs) : 0
  return `${phaseNum}.${maxSub + 1}`
}

// ── Version helpers ───────────────────────────────────────────────────────────

export function bumpPatchVersion(version: string): string {
  const parts = version.split('.')
  const major = parseInt(parts[0], 10) || 1
  const minor = parseInt(parts[1] || '0', 10)
  return `${major}.${String(minor + 1).padStart(2, '0')}`
}

export function bumpMajorVersion(version: string): string {
  const parts = version.split('.')
  const major = parseInt(parts[0], 10) || 1
  return `${major + 1}.00`
}

// ── Person roles for PIC datalist ────────────────────────────────────────────

export function getPersonRoles(type: PlanType): string[] {
  if (type === 'development') return ['Requestor', 'Designer', 'Developer', 'SE', 'PM', 'Manager']
  if (type === 'training') return ['Requestor', 'Trainer', 'SE', 'PM', 'Manager']
  return ['Requestor', 'SMART Member', 'SE', 'PM', 'Manager']
}

// Migrate old persons object → personsList array
export function migratePersonsToList(type: PlanType, persons: any): PersonEntry[] {
  if (!persons) return []
  const list: PersonEntry[] = []
  if (type === 'development') {
    if (persons.requestor?.trim()) list.push({ id: generateId(), role: 'Requestor', name: persons.requestor })
    if (persons.designer?.trim())  list.push({ id: generateId(), role: 'Designer',  name: persons.designer  })
    if (persons.developer?.trim()) list.push({ id: generateId(), role: 'Developer', name: persons.developer })
    if (persons.se?.trim())        list.push({ id: generateId(), role: 'SE',        name: persons.se        })
    if (persons.pm?.trim())        list.push({ id: generateId(), role: 'PM',        name: persons.pm        })
  } else {
    if (persons.requestor?.trim())   list.push({ id: generateId(), role: 'Requestor',    name: persons.requestor   })
    if (persons.smartMember?.trim()) list.push({ id: generateId(), role: 'Main Support', name: persons.smartMember })
    if (persons.se?.trim())          list.push({ id: generateId(), role: 'SE',           name: persons.se          })
    if (persons.pm?.trim())          list.push({ id: generateId(), role: 'PM',           name: persons.pm          })
  }
  return list
}

// Migrate personsList / legacy persons → Stakeholder[]
export function migrateToStakeholders(personsList?: PersonEntry[], persons?: any, type?: PlanType): Stakeholder[] {
  if (personsList && personsList.length > 0) {
    const map = new Map<string, Stakeholder>()
    for (const p of personsList) {
      if (!p.name?.trim()) continue
      const key = p.name.trim()
      const existing = map.get(key)
      if (existing) { if (!existing.roles.includes(p.role)) existing.roles.push(p.role) }
      else map.set(key, { id: p.id, name: key, roles: [p.role] })
    }
    if (map.size > 0) return Array.from(map.values())
  }
  if (persons) {
    const result: Stakeholder[] = []
    const add = (name: string, role: string) => {
      if (!name?.trim()) return
      const existing = result.find(s => s.name === name.trim())
      if (existing) { if (!existing.roles.includes(role)) existing.roles.push(role) }
      else result.push({ id: generateId(), name: name.trim(), roles: [role] })
    }
    if (type === 'development') {
      add(persons.requestor, 'Requestor'); add(persons.designer, 'Designer')
      add(persons.developer, 'Developer'); add(persons.se, 'SE'); add(persons.pm, 'PM')
    } else {
      add(persons.requestor, 'Requestor'); add(persons.smartMember, 'Main Support')
      add(persons.se, 'SE'); add(persons.pm, 'PM')
    }
    return result
  }
  return []
}

// Renumber all activities sequentially based on their position
export function renumberActivities(activities: ActivityRow[]): ActivityRow[] {
  let phaseNum = 0
  const subCount = new Map<number, number>()
  return activities.map(a => {
    if (a.isPhase) {
      phaseNum++
      subCount.set(phaseNum, 0)
      return { ...a, number: `${phaseNum}.0` }
    }
    const ph = phaseNum > 0 ? phaseNum : 1
    const sub = (subCount.get(ph) ?? 0) + 1
    subCount.set(ph, sub)
    return { ...a, number: `${ph}.${sub}` }
  })
}

// Auto-fill name for an approval slot role from stakeholders / personsList / legacy persons
export function autoFillNameForRole(role: string, type: PlanType, persons: DevPersons | SupportPersons, personsList?: PersonEntry[], stakeholders?: Stakeholder[]): string {
  const r = role.toUpperCase()
  if (stakeholders && stakeholders.length > 0) {
    if (r === 'PIC') {
      const main = stakeholders.find(s => s.roles.some(ro => ['Support PIC', 'Main Support', 'Developer'].includes(ro))) ?? stakeholders[0]
      return main?.name || ''
    }
    if (r === 'PROJECT LEADER') return stakeholders.find(s => s.roles.some(ro => ['Project Leader', 'PM'].includes(ro)))?.name || ''
    if (r === 'SUPERVISOR')     return stakeholders.find(s => s.roles.some(ro => ['Project Supervisor', 'System Expert', 'SE'].includes(ro)))?.name || ''
  }
  if (personsList && personsList.length > 0) {
    if (r === 'PIC') {
      const main = personsList.find(p => ['Main Support', 'Developer'].includes(p.role)) ?? personsList[0]
      return main?.name || ''
    }
    if (r === 'PROJECT LEADER') return personsList.find(p => p.role === 'PM')?.name || ''
    if (r === 'SUPERVISOR')     return personsList.find(p => p.role === 'SE')?.name || ''
  }
  const p = persons as DevPersons & SupportPersons
  if (r === 'PIC') return type === 'development' ? (p.developer || p.requestor || '') : (p.smartMember || p.requestor || '')
  if (r === 'PROJECT LEADER') return p.pm || ''
  if (r === 'SUPERVISOR') return p.se || ''
  return ''
}

// Replaces any freshly-uploaded signature images (still held in local state right after
// an upload/save) with an opaque placeholder — called right after a save/submit/approve
// action so a signer's own image never lingers visible in the UI once persisted. Server
// responses already redact signatures on every subsequent load; this just closes the gap
// for the remainder of the current browser session before a reload would do the same.
const SIGNATURE_PLACEHOLDER = '[[signed]]'
export function hideSignedImages(approvals: ApprovalSection): ApprovalSection {
  const keys = ['preparedBy', 'reviewedBy', 'approvedBy1', 'approvedBy2', 'approvedBy3'] as const
  const result = { ...approvals }
  for (const key of keys) {
    const slot = result[key]
    if (slot?.signatureImage?.startsWith('data:image/')) {
      result[key] = { ...slot, signatureImage: SIGNATURE_PLACEHOLDER }
    }
  }
  return result
}

// ── Plan creation ─────────────────────────────────────────────────────────────

function makeRow(number: string, name: string, isPhase: boolean, months: MonthConfig[]): ActivityRow {
  return {
    id: generateId(), number, name, isPhase,
    picEntries: [makePICEntry()],
    status: 'NOT YET STARTED', progress: 0, autoProgress: true, mh: 0, workingDays: 0,
    dayMarks: generateDayMarks(months),
  }
}

function defaultMonths(): MonthConfig[] {
  const now = new Date()
  const months: MonthConfig[] = []
  for (let i = 0; i < 3; i++) {
    const totalMonth = now.getMonth() + i
    months.push({ year: now.getFullYear() + Math.floor(totalMonth / 12), month: totalMonth % 12 })
  }
  return months
}

export function createDefaultPlan(type: PlanType): ActivityPlan {
  const months = defaultMonths()
  const today = new Date().toISOString().slice(0, 10)

  const devActivities: ActivityRow[] = [
    makeRow('1.0', 'Preparation', true, months),
    makeRow('1.1', 'Specs Discussion', false, months),
    makeRow('1.2', 'Activity Plan Creation', false, months),
    makeRow('1.3', 'RA', false, months),
    makeRow('2.0', 'Design', true, months),
    makeRow('2.1', 'RD', false, months),
    makeRow('3.0', 'Development', true, months),
    makeRow('3.1', 'Function 1', false, months),
    makeRow('4.0', 'Testing', true, months),
    makeRow('4.1', 'PG Test', false, months),
    makeRow('4.2', 'SE Test', false, months),
    makeRow('5.0', 'Implementation', true, months),
    makeRow('5.1', 'Release', false, months),
  ]

  const supportActivities: ActivityRow[] = [
    makeRow('1.0', 'Preparation', true, months),
    makeRow('1.1', 'Request Discussion', false, months),
    makeRow('2.0', 'Investigation', true, months),
    makeRow('2.1', 'Problem 1', false, months),
    makeRow('3.0', 'Fixing', true, months),
    makeRow('3.1', 'Fix', false, months),
    makeRow('4.0', 'Documentation', true, months),
    makeRow('4.1', 'Analysis Creation', false, months),
    makeRow('5.0', 'Cascading', true, months),
    makeRow('5.1', 'Cascading', false, months),
  ]

  const trainingActivities: ActivityRow[] = [
    makeRow('1.0', 'Preparation', true, months),
    makeRow('1.1', 'Material Preparation', false, months),
    makeRow('1.2', 'Venue / Setup', false, months),
    makeRow('2.0', 'Sessions', true, months),
    makeRow('2.1', 'Session 1', false, months),
    makeRow('3.0', 'Assessment', true, months),
    makeRow('3.1', 'Evaluation', false, months),
  ]

  const implementationActivities: ActivityRow[] = [
    makeRow('1.0', 'Kick-Off Meeting', true, months),
    makeRow('1.1', 'Kick-Off Meeting', false, months),
    makeRow('2.0', 'Technical Meeting', true, months),
    makeRow('2.1', 'Technical Meeting', false, months),
    makeRow('3.0', 'Preparation', true, months),
    makeRow('3.1', 'Preparation', false, months),
    makeRow('4.0', 'Actual Activities - Change Day', true, months),
    makeRow('4.1', 'Actual Activities - Change Day', false, months),
    makeRow('5.0', 'Testing', true, months),
    makeRow('5.1', 'Testing', false, months),
    makeRow('6.0', 'Judgement', true, months),
    makeRow('6.1', 'Judgement', false, months),
    makeRow('7.0', 'Closing', true, months),
    makeRow('7.1', 'Closing', false, months),
  ]

  const devPersons: DevPersons = { requestor: '', designer: '', developer: '', se: '', pm: '' }
  const supportPersons: SupportPersons = { requestor: '', smartMember: '', se: '', pm: '' }

  return {
    id: generateUUID(),
    type,
    title: '',
    documentVersion: '1.00',
    groupType: undefined,
    persons: type === 'development' ? devPersons : supportPersons,
    personsList: [],
    stakeholders: [],
    additionalPersons: [],
    approvals: {
      preparedBy:  { name: '', role: 'PIC',              remarks: '' },
      reviewedBy:  { name: '', role: 'PROJECT LEADER',   remarks: '' },
      approvedBy1: { name: '', role: 'SUPERVISOR',       remarks: '' },
      approvedBy2: { name: '', role: 'SECTION MANAGER',  remarks: '' },
    },
    activities: type === 'development' ? devActivities
      : type === 'training' ? trainingActivities
      : type === 'implementation' ? implementationActivities
      : supportActivities,
    months,
    otDays: [],
    status: 'draft',
    versionHistory: [{ version: '1.00', date: today, reason: 'Initial creation', by: '' }],
  }
}

// ── Progress / status calculation ─────────────────────────────────────────────

export interface PlanStatus {
  label: 'COMPLETE' | 'ON TIME' | 'AT RISK' | 'DELAYED' | 'NOT STARTED'
  progress: number
  daysLeft: number | null
  expectedProgress: number
  // Short, always-available explanation of why the label is what it is — cheap to
  // compute (pure math on progress/expectedProgress/daysLeft), shown next to the
  // badge wherever it appears. A deeper "which activities" breakdown lives in Insights.
  reason: string
}

function plural(n: number, word: string): string {
  return `${n} ${word}${n === 1 ? '' : 's'}`
}

export function calcPlanStatus(plan: ActivityPlan): PlanStatus {
  const nonPhase = plan.activities.filter(a => !a.isPhase)

  // Weighted average of per-row effective progress.
  // Weight = plan mark count (days scheduled); falls back to MH if no marks are set.
  let totalWeight = 0
  let weightedProgress = 0
  for (const row of nonPhase) {
    const planCount = (row.dayMarks ?? []).filter(d => d.plan).length
    const weight = planCount > 0 ? planCount : row.mh
    if (weight <= 0) continue
    const rowProgress = row.autoProgress !== false ? calcAutoProgress(row) : row.progress
    totalWeight += weight
    weightedProgress += weight * rowProgress
  }
  const progress = totalWeight > 0 ? weightedProgress / totalWeight : 0

  if (progress >= 100) return { label: 'COMPLETE', progress: 100, daysLeft: 0, expectedProgress: 100, reason: 'All activities completed.' }

  if (!plan.targetDate) return { label: 'NOT STARTED', progress, daysLeft: null, expectedProgress: 0, reason: 'No target date set yet.' }

  const todayMs = Date.now()
  const targetMs = new Date(plan.targetDate).getTime()
  const startMs = plan.startDate
    ? new Date(plan.startDate + 'T00:00:00').getTime()
    : plan.months.length > 0
      ? new Date(plan.months[0].year, plan.months[0].month, 1).getTime()
      : todayMs
  if (todayMs < startMs) return { label: 'NOT STARTED', progress, daysLeft: null, expectedProgress: 0, reason: "Start date hasn't arrived yet." }
  const totalMs = targetMs - startMs
  const elapsedMs = todayMs - startMs
  const expectedProgress = totalMs > 0 ? Math.min(Math.max((elapsedMs / totalMs) * 100, 0), 100) : 0
  const daysLeft = Math.ceil((targetMs - todayMs) / 86400000)
  const gap = expectedProgress - progress

  if (daysLeft < 0) {
    return {
      label: 'DELAYED', progress, daysLeft, expectedProgress,
      reason: `Target date passed ${plural(Math.abs(daysLeft), 'day')} ago, at ${progress.toFixed(0)}% complete.`,
    }
  }
  if (progress >= expectedProgress - 5) {
    return {
      label: 'ON TIME', progress, daysLeft, expectedProgress,
      reason: gap <= 0 ? `Ahead of pace by ${Math.abs(gap).toFixed(0)} points.` : 'Within 5 points of the expected pace.',
    }
  }
  if (progress >= expectedProgress - 20) {
    return {
      label: 'AT RISK', progress, daysLeft, expectedProgress,
      reason: `${gap.toFixed(0)} points behind pace, with ${plural(daysLeft, 'day')} left — likely an activity hasn't been started or updated yet.`,
    }
  }
  return {
    label: 'DELAYED', progress, daysLeft, expectedProgress,
    reason: `${gap.toFixed(0)} points behind pace with only ${plural(daysLeft, 'day')} left — multiple activities are likely behind schedule.`,
  }
}

// Auto-progress: 100% if DONE, else actual marks ÷ plan marks
// e.g. 2 plan days, 1 actual mark → 50%
export function calcAutoProgress(row: { dayMarks: { date: string; plan: boolean; actual: boolean }[]; status?: string }): number {
  if (row.status === 'DONE') return 100
  const planCount = row.dayMarks.filter(d => d.plan).length
  if (planCount === 0) return 0
  const actualCount = row.dayMarks.filter(d => d.actual).length
  return Math.min(100, Math.round((actualCount / planCount) * 100))
}

export const STATUS_OPTIONS = ['NOT YET STARTED', 'ONGOING', 'DONE', 'ON HOLD'] as const
export const CHECK_OPTIONS = ['', 'OK', 'NG', 'N/A'] as const
